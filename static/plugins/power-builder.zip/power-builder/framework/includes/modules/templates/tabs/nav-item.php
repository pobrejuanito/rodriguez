<?php
/**
 * Template part for displaying tabs navigation item
 */
?>
<li class="<?php echo $this->_var( 'classes' ); ?>">
	<a href="#"><?php echo $this->_var( 'tab_title' ); ?></a>
</li>